//#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE unit_tests
#include<boost/test/unit_test.hpp>
